%close all
clear all

BR=100e9;

BR=100e9;
Lsim=100e3;
LW=10e3;
laser_offset = 0e9;

% Generamos simbolos
aki = 2*randi([0 3],Lsim,1)-3;
akq = 2*randi([0 3],Lsim,1)-3;
ak=aki+1j*akq;

% Agrego algo de ruido
Pn=0.08;
noise=sqrt(Pn/2)*(randn(size(ak)) + 1j*randn(size(ak)));
zk=ak+noise;

% Agrego los efctos de la portadora


% plot(zk,'.')
% LO offset
tline=(0:length(zk)-1)'/BR;
phase_lo_offset=2*pi*laser_offset*tline;

% Phase noise
freq_noise = sqrt(2*pi*LW/BR)*randn(size(zk));
phase_noise = cumsum(freq_noise);
laser_output = exp(1j*(phase_noise+phase_lo_offset));

rk=zk.*laser_output;

figure
plot(rk,'.')
xlim([-5,5])
ylim([-5,5])
grid on








% 
% 
