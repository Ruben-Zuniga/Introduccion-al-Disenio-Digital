%close all
clear all

BR=100e9;
Lsim=2500e3;
LW=0e6;
laser_offset = 10e9;

tline=(0:Lsim-1)'/BR;
phase_lo_offset=2*pi*laser_offset*tline;

Nexps=10;

%figure
for n=1:Nexps
    % Para armar el ruido de wiener tengo que integrar un ruido blanco
    % Armo el vector de ruido blanco (ruido de frecuencia)
    freq_noise = sqrt(2*pi*LW/BR)*randn(Lsim,1);
    phase_noise = cumsum(freq_noise);
    laser_output = exp(1j*(phase_noise+phase_lo_offset));
    [pxx,fv]=pwelch(laser_output,[],0,Lsim,BR);
    
    if n==1
        pxx_accum=pxx/Nexps;
    else
        pxx_accum=pxx_accum+pxx/Nexps;
    end
    
%     plot(phase_noise)
%     hold all
    
end

% xlabel('Time [samples]')
% ylabel("Phase [rad]")
% grid on

figure
plot(fv/1e9,10*log10(pxx_accum));
grid on