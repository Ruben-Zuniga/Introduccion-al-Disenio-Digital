function o_array = slicer_pam(i_array, n_levels)

    i_array = real(i_array);
    o_array = -1 * ones(size(i_array));
    
    switch n_levels
        case 2
            o_array(i_array > 0) = 1 ;
            
        case 4
            o_array(i_array >= 2 ) =  3;
            o_array(i_array < -2 ) = -3;
            o_array(i_array >  0 & i_array < 2) = 1;                      

        case 6
            o_array(i_array >= 4 ) =  5;
            o_array(i_array < -4 ) = -5;
            o_array(i_array >= 2 & i_array <  4) =  3;
            o_array(i_array < -2 & i_array > -4) = -3;
            o_array(i_array >  0 & i_array <  2) =  1;

        case 8
            o_array(i_array >= 6 ) = 7;
            o_array(i_array <=-6 ) = -7;
            o_array(i_array >= 4 & i_array <  6) =  5;
            o_array(i_array <=-4 & i_array > -6) = -5;
            o_array(i_array >= 2 & i_array <  4) =  3;
            o_array(i_array <=-2 & i_array > -4) = -3;
            o_array(i_array >= 0 & i_array <  2) =  1;
            
        otherwise
            error("The selected modulationType is not supported");
    end
end

