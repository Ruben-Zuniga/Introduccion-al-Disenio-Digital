clear all
close all

M=16;
BR=100e9;
Lsim=100e3;
LW=00e3;
laser_offset = 10e6;

% Generamos simbolos (siempre es qam16, guarda)
aki = 2*randi([0 3],Lsim,1)-3;
akq = 2*randi([0 3],Lsim,1)-3;
ak=aki+1j*akq;

% Agrego algo de ruido
Pn=0.08;
noise=sqrt(Pn/2)*(randn(size(ak)) + 1j*randn(size(ak)));
zk=ak+noise;

% Agrego los efctos de la portadora


% plot(zk,'.')
% LO offset
tline=(0:length(zk)-1)'/BR;
phase_lo_offset=2*pi*laser_offset*tline;

% Phase noise
freq_noise = sqrt(2*pi*LW/BR)*randn(size(zk));
phase_noise = cumsum(freq_noise);
laser_output = exp(1j*(phase_noise+phase_lo_offset));

rk=zk.*laser_output;



%%
% Descripcion del PLL asistido por decisiones
Ls=length(rk);
fcr_output = zeros(Ls,1);
phase_error= zeros(Ls,1);
prop_loop_filter= zeros(Ls,1);
inte_loop_filter= zeros(Ls,1);
nco_input = zeros(Ls,1);
nco_output= zeros(Ls,1);

Kp=10e-3;
Ki=Kp/1000;

for m=2:Ls
    
    % Datapath
    yk=rk(m)*exp(-1j*nco_output(m-1));
    fcr_output(m)=yk;
    
    % Calculo del error de fase
    ak_hat=slicer_QAM(yk,M);
    epsilon=angle(yk*conj(ak_hat));
    phase_error(m)=epsilon;
    
    %Loop filter
    prop_loop_filter(m) = Kp*epsilon;
    inte_loop_filter(m) = inte_loop_filter(m-1)+Ki*epsilon;
    nco_input(m)=prop_loop_filter(m)+inte_loop_filter(m);
    
    nco_output(m) = nco_output(m-1) + nco_input(m);
end

figure
plot(phase_error)
grid on
xlabel("Time [samples]")
ylabel("Phase Error")

figure
subplot 211
plot(prop_loop_filter)
grid on
xlabel("Time [samples]")
ylabel("Prop Filter")
subplot 212
plot(inte_loop_filter*BR/2/pi)
grid on
xlabel("Time [samples]")
ylabel("Inte Filter [MHz]")

figure
plot(nco_output)
hold all
plot(phase_noise)
grid on
xlabel("Time [samples]")
ylabel("NCO Output")
legend("NCO FCR","Phase Noise Channel")

figure
subplot 121
plot(rk,'.')
xlim([-5,5])
ylim([-5,5])
grid on
subplot 122
plot(fcr_output,'.')
xlim([-5,5])
ylim([-5,5])
grid on

%%

 
    
    




